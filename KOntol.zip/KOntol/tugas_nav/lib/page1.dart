import 'package:flutter/material.dart';

class Page1 extends StatelessWidget {
  const Page1({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Halaman 1")),
      body: Column(
        children: [
          // Teks Selamat Datang
          Center(
            child: Container(
              padding: const EdgeInsets.all(16.0),
              color: Colors.blueAccent,
              child: const Text(
                'Selamat datang di Halaman 1',
                style: TextStyle(fontSize: 20, color: Colors.white),
              ),
            ),
          ),
          const SizedBox(height: 20),
          // Grid Layout dengan 3 lingkaran dan 3 segitiga
          Expanded(
            child: GridView.count(
              crossAxisCount: 3, // 3 kolom
              children: [
                // Lingkaran 1
                Container(
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.redAccent,
                  ),
                  margin: const EdgeInsets.all(8.0),
                ),
                // Lingkaran 2
                Container(
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.greenAccent,
                  ),
                  margin: const EdgeInsets.all(8.0),
                ),
                // Lingkaran 3
                Container(
                  decoration: const BoxDecoration(
                    shape: BoxShape.circle,
                    color: Colors.blueAccent,
                  ),
                  margin: const EdgeInsets.all(8.0),
                ),
                // Segitiga 1
                Transform.rotate(
                  angle: 3.14 / 4, // Rotasi untuk membentuk segitiga
                  child: Container(
                    width: 20,
                    height: 20,
                    color: Colors.yellow,
                    child: CustomPaint(
                      painter: TrianglePainter(),
                    ),
                  ),
                ),
                // Segitiga 2
                Transform.rotate(
                  angle: 3.14 / 4,
                  child: Container(
                    width: 20,
                    height: 20,
                    color: Colors.purpleAccent,
                    child: CustomPaint(
                      painter: TrianglePainter(),
                    ),
                  ),
                ),
                // Segitiga 3
                Transform.rotate(
                  angle: 3.14 / 4,
                  child: Container(
                    width: 20,
                    height: 20,
                    color: Colors.orangeAccent,
                    child: CustomPaint(
                      painter: TrianglePainter(),
                    ),
                  ),
                ),
              ],
            ),
          ),
          // Tombol Navigasi ke Halaman 2
          ElevatedButton(
            onPressed: () {
              Navigator.pushNamed(context, '/page2');
            },
            child: const Text('Ke Halaman 2'),
          ),
        ],
      ),
    );
  }
}

// Custom Painter untuk membuat segitiga
class TrianglePainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()..color = Colors.black;
    final path = Path();

    path.moveTo(size.width / 2, 0); // Titik atas
    path.lineTo(0, size.height); // Titik kiri bawah
    path.lineTo(size.width, size.height); // Titik kanan bawah
    path.close();

    canvas.drawPath(path, paint);
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) {
    return false;
  }
}
