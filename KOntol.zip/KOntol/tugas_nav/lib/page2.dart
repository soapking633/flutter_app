import 'package:flutter/material.dart';

class Page2 extends StatelessWidget {
  const Page2({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title: const Text("Halaman 2")), // Hapus const jika terjadi kesalahan
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Container(
              // Hapus const di sini karena ini adalah widget dengan properti dinamis
              padding:
                  const EdgeInsets.all(16.0), // Tetap gunakan const di sini
              color: Colors.greenAccent,
              child: const Text(
                // Tetap const pada Text yang tidak berubah
                'Ini adalah Halaman 2',
                style: TextStyle(fontSize: 20, color: Colors.black),
              ),
            ),
            const SizedBox(height: 20), // Tetap gunakan const untuk SizedBox
            // Kotak
            Container(
              // Hapus const di sini
              width: 100,
              height: 100,
              color: Colors.blue,
            ),
            const SizedBox(height: 20), // Tetap gunakan const untuk SizedBox
            // Baris bintang
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: List.generate(5, (index) {
                return const Icon(Icons.star,
                    color: Colors.yellow, size: 40); // Tetap const di sini
              }),
            ),
            const SizedBox(height: 20), // Tetap gunakan const untuk SizedBox
            // Tombol untuk berpindah ke Halaman 3
            ElevatedButton(
              onPressed: () {
                Navigator.pushNamed(context, '/page3');
              },
              child:
                  const Text('Ke Halaman 3'), // Tetap gunakan const untuk Text
            ),
          ],
        ),
      ),
    );
  }
}
