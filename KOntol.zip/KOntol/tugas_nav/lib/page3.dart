import 'package:flutter/material.dart';

class Page3 extends StatelessWidget {
  // Konstruktor dengan parameter key untuk mematuhi pedoman penggunaan key
  const Page3({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
          title:
              const Text("Halaman 3")), // Tidak ada 'const' pada widget AppBar
      body: Column(
        children: [
          // Teks di atas layout
          Center(
            child: Container(
              padding: const EdgeInsets.all(
                  16.0), // 'const' digunakan pada EdgeInsets
              color: Colors.redAccent,
              child: const Text(
                // Menggunakan 'const' pada Text karena bisa menjadi konstanta
                'Anda berada di Halaman 3',
                style: TextStyle(fontSize: 20, color: Colors.white),
              ),
            ),
          ),
          const SizedBox(height: 20), // Menggunakan 'const' pada SizedBox
          // Grid Layout
          Expanded(
            child: GridView.count(
              crossAxisCount: 2, // 2 kolom
              padding: const EdgeInsets.all(
                  10.0), // 'const' digunakan pada EdgeInsets
              crossAxisSpacing: 10,
              mainAxisSpacing: 10,
              children: [
                // Item 1
                Container(
                  padding: const EdgeInsets.all(
                      8.0), // 'const' digunakan pada EdgeInsets
                  color: Colors.blue[300],
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(Icons.star, color: Colors.white, size: 50),
                      SizedBox(height: 10),
                      Text(
                        "Bintang",
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ],
                  ),
                ),
                // Item 2
                Container(
                  padding: const EdgeInsets.all(
                      8.0), // 'const' digunakan pada EdgeInsets
                  color: Colors.green[300],
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(Icons.favorite, color: Colors.white, size: 50),
                      SizedBox(height: 10),
                      Text(
                        "Favorit",
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ],
                  ),
                ),
                // Item 3
                Container(
                  padding: const EdgeInsets.all(
                      8.0), // 'const' digunakan pada EdgeInsets
                  color: Colors.orange[300],
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(Icons.access_alarm, color: Colors.white, size: 50),
                      SizedBox(height: 10),
                      Text(
                        "Alarm",
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ],
                  ),
                ),
                // Item 4
                Container(
                  padding: const EdgeInsets.all(
                      8.0), // 'const' digunakan pada EdgeInsets
                  color: Colors.purple[300],
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(Icons.settings, color: Colors.white, size: 50),
                      SizedBox(height: 10),
                      Text(
                        "Pengaturan",
                        style: TextStyle(color: Colors.white, fontSize: 16),
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
          // Tombol kembali ke Halaman 1
          ElevatedButton(
            onPressed: () {
              Navigator.pushNamed(context, '/');
            },
            child: const Text('Kembali ke Halaman 1'),
          ),
        ],
      ),
    );
  }
}
